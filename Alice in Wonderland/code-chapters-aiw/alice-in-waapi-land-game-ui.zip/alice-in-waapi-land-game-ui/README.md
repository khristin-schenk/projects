# Alice in WAAPI Land Game UI

A Pen created on CodePen.io. Original URL: [https://codepen.io/rachelnabors/pen/zrVQGp](https://codepen.io/rachelnabors/pen/zrVQGp).

This shows at the end of the game. Wanted to stand it alone so we could play wit the Web Animations API and UI animations a bit!