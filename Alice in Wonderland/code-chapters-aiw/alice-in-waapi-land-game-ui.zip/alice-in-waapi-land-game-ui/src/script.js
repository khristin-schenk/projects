/* Pull #learn-more into space when  */
var learnMoreButton = document.getElementById("learn-more_button");

var seeLearnMore = document.getElementById("ending-ui_panels").animate([
  { opacity: 1, transform: 'translateX(0)'}, 
  { opacity: 0, transform: 'translateX(0)', offset: .33 }, 
  { opacity: 0, transform: 'translateX(-66.67%)', offset: .66},
  { opacity: 1, transform: 'translateX(-66.67%)'}
], {
  duration: 400,
  easing: 'cubic-bezier(0.23, 1, 0.32, 1)',
  fill: 'forwards'
});
seeLearnMore.pause();

var learnMore = function(e) {
  e.preventDefault();
  seeLearnMore.play();
}

learnMoreButton.addEventListener("click", learnMore);
learnMoreButton.addEventListener("touchStart", learnMore);

/* For buttons that reset all the page's animations. All of them. */

var resetAllTheThings = function() {
  seeLearnMore.currentTime = 0;
  seeLearnMore.pause();
}

Array.prototype.forEach.call(document.getElementsByClassName("play-again"), function(button) {
  button.addEventListener("click", resetAllTheThings);
  button.addEventListener("touchStart", resetAllTheThings);
});

/* Should you ever need to loop through all the animations */
// Array.prototype.forEach.call(document.getElementsByTagName("*"), function(element) {

//   // if the element has animations
//   if (element.getAnimations().length > 0) {
//     console.log(element.getAnimations())

//     // restart each of them
//     Array.prototype.forEach.call(element.getAnimations(), function(animation) {
//       console.log(animation.currentTime);

//       animation.currentTime = 0;
//       animation.pause();
//     });

//   }
// });
