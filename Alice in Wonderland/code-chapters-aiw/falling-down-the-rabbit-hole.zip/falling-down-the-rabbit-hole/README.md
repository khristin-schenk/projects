# Falling Down the Rabbit Hole

A Pen created on CodePen.io. Original URL: [https://codepen.io/rachelnabors/pen/nwpVNx](https://codepen.io/rachelnabors/pen/nwpVNx).

A little sequence using waypoints.js and skrollr.js to change Alice's "attitude" as you make her "fall" down the rabbit hole with scrolling.

I did all the art. You can read the full version here: http://rachelnabors.com/alice-in-videoland/book 

At the very end are links to the github repo + 2 tutorial articles I wrote about how I did it.