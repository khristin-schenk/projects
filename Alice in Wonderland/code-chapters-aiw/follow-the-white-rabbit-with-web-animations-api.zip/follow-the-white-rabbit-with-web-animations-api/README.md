# Follow the White Rabbit (with Web Animations API)

A Pen created on CodePen.io. Original URL: [https://codepen.io/rachelnabors/pen/eJyWzm](https://codepen.io/rachelnabors/pen/eJyWzm).

Recreating the CSS Transitions from http://codepen.io/rachelnabors/pen/adVpaX/ with the Web Animation API.