# Growing/Shrinking Alice Game : Alice in Web Animations API Land

A Pen created on CodePen.io. Original URL: [https://codepen.io/rachelnabors/pen/PNYGZQ](https://codepen.io/rachelnabors/pen/PNYGZQ).

All the pens brought together into one fun game that runs entirely on the Web Animations API... and timelines.