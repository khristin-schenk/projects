# Open a Book - CSS Website loader

A Pen created on CodePen.io. Original URL: [https://codepen.io/TheSonOfThomp/pen/zYBOBPd](https://codepen.io/TheSonOfThomp/pen/zYBOBPd).

