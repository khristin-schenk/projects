# Poor Alice! (Forgot the Key) w/ Web Animations API

A Pen created on CodePen.io. Original URL: [https://codepen.io/rachelnabors/pen/bEPdQr](https://codepen.io/rachelnabors/pen/bEPdQr).

Here we see that Alice forgot to get the key! An end state for a small game lovingly crafted with the Web Animations API.