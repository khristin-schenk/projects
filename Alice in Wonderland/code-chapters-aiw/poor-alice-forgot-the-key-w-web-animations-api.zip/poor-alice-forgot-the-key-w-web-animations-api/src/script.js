var omgDuration = 600;

document.getElementById("exclaim").animate(
  [  
    { opacity: 0 }, 
    { opacity: 1 },
    { opacity: 1 }
  ], 
  {
    easing: 'steps(2, end)',
    iterations: Infinity,
    direction: 'alternate',
    duration: omgDuration
  }
);

document.getElementById("alice_arm").animate([  
    { transform: 'rotate(10deg)' }, 
    { transform: 'rotate(-40deg)' }
  ], 
  {
    easing: 'steps(2, end)',
    iterations: Infinity,
    direction: 'alternate',
    duration: omgDuration
  }
);

document.getElementById("alice_too-small").animate([  
    { transform: 'translateX(-50%) scale(1.1)' }, 
    { transform: 'translateX(-50%) scale(1)' }
  ], 
  {
    easing: 'easeOut',
    duration: 600,
    fill: 'forwards'
  }
);