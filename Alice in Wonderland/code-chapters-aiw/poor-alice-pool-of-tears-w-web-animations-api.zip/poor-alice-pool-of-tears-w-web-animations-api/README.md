# Poor Alice! (Pool of Tears) w/ Web Animations API

A Pen created on CodePen.io. Original URL: [https://codepen.io/rachelnabors/pen/EPJdJx](https://codepen.io/rachelnabors/pen/EPJdJx).

Using the Web Animations API to show Alice crying into a pull of tears. One possible ending of http://codepen.io/rachelnabors/pen/35936ab4c3be0a82fc82e460601268da?editors=0100