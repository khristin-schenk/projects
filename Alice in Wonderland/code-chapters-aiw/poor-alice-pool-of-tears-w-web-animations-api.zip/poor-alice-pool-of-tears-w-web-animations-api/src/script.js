var tearsFalling = [
  { transform: 'translate3D(0, 0, 0)' }, 
  { transform: 'translate3D(0, 2850%, 0)' }, 
];

var tears = document.querySelectorAll('.tear');
tears = Array.prototype.slice.call(tears);

document.getElementById("pool").animate(
  [
    { transform: 'scale(.8)' }, 
    { transform: 'scale(1)' }, 
  ], 
  {
    duration: 10000,
    fill: 'forwards'
  });

var getRandomMsRange = function(min, max) {
  return Math.random() * (max - min) + min;
}

tears.forEach(function(el) {  
  el.animate(
    tearsFalling, 
    {
      delay: getRandomMsRange(-1000, 1000), // randomized for each tear
      duration: getRandomMsRange(2000, 6000), // randomized for each tear
      iterations: Infinity,
      easing: "cubic-bezier(0.6, 0.04, 0.98, 0.335)"
    });
});